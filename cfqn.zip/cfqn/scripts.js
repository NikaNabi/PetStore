// Получение элементов
const cartModal = document.getElementById('cart-modal');
const closeCartBtn = document.getElementById('close-cart-btn');
const cartItemsContainer = document.getElementById('cart-items');
const totalPriceElem = document.getElementById('total-price');
const addToCartButtons = document.querySelectorAll('.add-to-cart');

// Массив для хранения товаров в корзине
let cart = [];

// Функция для добавления товара в корзину
function addToCart(productName, productPrice) {
  // Создаем объект товара
  const product = {
    name: productName,
    price: productPrice,
  };

  // Добавляем товар в корзину
  cart.push(product);

  // Обновляем отображение корзины
  updateCart();
}

// Функция для обновления отображения корзины
function updateCart() {
  // Очищаем контейнер корзины
  cartItemsContainer.innerHTML = '';

  let total = 0;

  // Проходим по всем товарам в корзине и добавляем их в HTML
  cart.forEach(item => {
    const itemElem = document.createElement('div');
    itemElem.classList.add('cart-item');
    itemElem.innerHTML = 
      `<p>${item.h3}</p>
      <p>${item.p}₽</p>`
    ;
    cartItemsContainer.appendChild(itemElem);

    // Суммируем цену товаров
    total += item.price;
  });

  // Обновляем итоговую сумму
  totalPriceElem.textContent = `${total}₽`;
}

// Обработчик кликов по кнопкам "Добавить в корзину"
addToCartButtons.forEach(button => {
  button.addEventListener('click', function () {
    const productName = button.getAttribute('data-name');
    const productPrice = parseFloat(button.getAttribute('data-price'));

    addToCart(productName, productPrice);
  });
});

// Открытие модального окна корзины
function openCart() {
  cartModal.style.display = 'block';
}

// Закрытие модального окна корзины
closeCartBtn.onclick = function() {
  cartModal.style.display = 'none';
}

// Закрытие корзины при клике за ее пределами
window.onclick = function(event) {
  if (event.target == cartModal) {
    cartModal.style.display = 'none';
  }
}

// Пример открытия корзины (например, при клике на кнопку)
document.getElementById('cart-btn').addEventListener('click', openCart);
// Получаем элементы
const cartBtn = document.getElementById('cart-btn'); // Кнопка корзины
const closeModalBtn = document.getElementById('close-modal'); // Кнопка закрытия модального окна

// Функция для открытия модального окна
cartBtn.addEventListener('click', () => {
  cartModal.style.display = 'block'; // Показываем модальное окно
});

// Функция для закрытия модального окна
closeModalBtn.addEventListener('click', () => {
  cartModal.style.display = 'none'; // Скрываем модальное окно
});

// Закрытие модального окна, если кликнуть вне его содержимого
window.addEventListener('click', (event) => {
  if (event.target === cartModal) {
    cartModal.style.display = 'none'; // Скрываем модальное окно
  }
});

// Получаем кнопку "Перейти к оплате"
const checkoutBtn = document.getElementById('checkout-btn');

// Добавляем обработчик события на клик по кнопке
checkoutBtn.addEventListener('click', () => {
  // Переходим на страницу оплаты
  window.location.href = 'payment.html';
});
// Получаем элементы кнопок для входа и регистрации
const loginToggle = document.getElementById('login-toggle');
const registerToggle = document.getElementById('register-toggle');

// Получаем сами формы
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');

// Переключаем формы при клике на кнопки
loginToggle.addEventListener('click', () => {
  loginForm.style.display = 'block';
  registerForm.style.display = 'none';
});

registerToggle.addEventListener('click', () => {
  registerForm.style.display = 'block';
  loginForm.style.display = 'none';
});

// Изначально показываем форму для входа
loginForm.style.display = 'block';
registerForm.style.display = 'none';
// Обработчик для формы входа
document.getElementById('login-form-element').addEventListener('submit', function(event) {
    event.preventDefault(); // Отменяем стандартное поведение формы
  
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
  
    // Пример проверки данных (можно добавить реальную валидацию или подключение к серверу)
    if (email && password) {
      // Если данные введены, редиректим на главную страницу
      window.location.href = 'index.html';
    } else {
      alert('Пожалуйста, заполните все поля!');
    }
  });
  
  // Обработчик для формы регистрации
  document.getElementById('register-form-element').addEventListener('submit', function(event) {
    event.preventDefault(); // Отменяем стандартное поведение формы
  
    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('register-confirm-password').value;
  
    // Пример проверки данных
    if (password === confirmPassword) {
      // Если все в порядке, редиректим на главную страницу
      window.location.href = 'index.html';
    } else {
      alert('Пароли не совпадают!');
    }
  });
  const user = localStorage.getItem('user');
  if (user) {
    // Отображать кнопку "Выйти" и скрывать "Вход"
  } else {
    // Показывать кнопку "Вход"
  }
  
// Пример для кнопки "Выйти" (если используется авторизация на клиентской стороне)
document.getElementById('logout-btn').addEventListener('click', function(event) {
    event.preventDefault();
    // Очищаем данные пользователя из localStorage или sessionStorage (если такие использовались)
    localStorage.removeItem('user');
    sessionStorage.removeItem('user');
    // Перенаправляем на страницу входа
    window.location.href = 'login-register.html';
  });
  document.getElementById('payment-form').addEventListener('submit', function (event) {
    event.preventDefault(); // Предотвращаем стандартную отправку формы
  
    const cardNumber = document.getElementById('card-number').value;
    const cardExpiry = document.getElementById('card-expiry').value;
    const cardCVC = document.getElementById('card-cvc').value;
    const address = document.getElementById('address').value;
  
    // Для демонстрации выводим данные в консоль
    console.log('Card Number:', cardNumber);
    console.log('Card Expiry:', cardExpiry);
    console.log('Card CVC:', cardCVC);
    console.log('Address:', address);
  
    // Здесь нужно будет интегрировать с платёжной системой для реальной обработки данных
  });